#!/bin/bash -ex

BOARD_ID=arduino_zero NAME=samd21_sam_ba make clean all

BOARD_ID=flasher NAME=flasher_bootloader make clean all

echo Done building bootloaders!

